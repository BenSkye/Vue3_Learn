<script setup lang="ts"></script>

<template>
	<div class="select-none font-Manrope">
		<router-view></router-view>
	</div>
</template>
